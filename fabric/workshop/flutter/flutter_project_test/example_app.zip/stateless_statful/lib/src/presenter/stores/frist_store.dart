import 'package:flutter/foundation.dart';

class FristStore extends ChangeNotifier {
  
}