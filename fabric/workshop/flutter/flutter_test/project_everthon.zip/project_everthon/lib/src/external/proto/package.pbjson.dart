// This is a generated file - do not edit.
//
// Generated from package.proto.

// @dart = 3.3

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names
// ignore_for_file: curly_braces_in_flow_control_structures
// ignore_for_file: deprecated_member_use_from_same_package, library_prefixes
// ignore_for_file: non_constant_identifier_names, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use userDescriptor instead')
const User$json = {
  '1': 'User',
  '2': [
    {'1': 'name', '3': 1, '4': 2, '5': 9, '10': 'name'},
    {'1': 'email', '3': 2, '4': 2, '5': 9, '10': 'email'},
    {'1': 'address', '3': 3, '4': 2, '5': 9, '10': 'address'},
  ],
};

/// Descriptor for `User`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List userDescriptor = $convert.base64Decode(
    'CgRVc2VyEhIKBG5hbWUYASACKAlSBG5hbWUSFAoFZW1haWwYAiACKAlSBWVtYWlsEhgKB2FkZH'
    'Jlc3MYAyACKAlSB2FkZHJlc3M=');
